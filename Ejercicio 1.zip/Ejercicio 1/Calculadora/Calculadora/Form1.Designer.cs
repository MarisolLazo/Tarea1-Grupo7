﻿namespace Calculadora
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Titlelabel1 = new Label();
            primernumerotextBox1 = new TextBox();
            Titlelabel2 = new Label();
            segundonumerotextBox2 = new TextBox();
            calcularSumsabutton = new Button();
            Resultadolabel = new Label();
            calcularRestarbutton = new Button();
            calcularMultiplicarbutton = new Button();
            tercerlabel = new Label();
            tercernumerotextBox3 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            SuspendLayout();
            // 
            // Titlelabel1
            // 
            Titlelabel1.AutoSize = true;
            Titlelabel1.BackColor = SystemColors.ButtonFace;
            Titlelabel1.Font = new Font("Showcard Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Titlelabel1.ForeColor = SystemColors.HotTrack;
            Titlelabel1.Location = new Point(144, 54);
            Titlelabel1.Margin = new Padding(4, 0, 4, 0);
            Titlelabel1.Name = "Titlelabel1";
            Titlelabel1.Size = new Size(191, 28);
            Titlelabel1.TabIndex = 1;
            Titlelabel1.Text = "Primer Numero";
            // 
            // primernumerotextBox1
            // 
            primernumerotextBox1.Location = new Point(389, 47);
            primernumerotextBox1.Margin = new Padding(4, 3, 4, 3);
            primernumerotextBox1.Name = "primernumerotextBox1";
            primernumerotextBox1.Size = new Size(631, 35);
            primernumerotextBox1.TabIndex = 2;
            // 
            // Titlelabel2
            // 
            Titlelabel2.AutoSize = true;
            Titlelabel2.BackColor = SystemColors.ButtonFace;
            Titlelabel2.Font = new Font("Showcard Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Titlelabel2.ForeColor = SystemColors.HotTrack;
            Titlelabel2.Location = new Point(144, 139);
            Titlelabel2.Margin = new Padding(4, 0, 4, 0);
            Titlelabel2.Name = "Titlelabel2";
            Titlelabel2.Size = new Size(206, 28);
            Titlelabel2.TabIndex = 3;
            Titlelabel2.Text = "Segundo Numero";
            // 
            // segundonumerotextBox2
            // 
            segundonumerotextBox2.Location = new Point(389, 132);
            segundonumerotextBox2.Margin = new Padding(4, 3, 4, 3);
            segundonumerotextBox2.Name = "segundonumerotextBox2";
            segundonumerotextBox2.Size = new Size(631, 35);
            segundonumerotextBox2.TabIndex = 4;
            // 
            // calcularSumsabutton
            // 
            calcularSumsabutton.Font = new Font("Algerian", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            calcularSumsabutton.ForeColor = SystemColors.Desktop;
            calcularSumsabutton.Location = new Point(122, 338);
            calcularSumsabutton.Margin = new Padding(4, 3, 4, 3);
            calcularSumsabutton.Name = "calcularSumsabutton";
            calcularSumsabutton.Size = new Size(242, 77);
            calcularSumsabutton.TabIndex = 5;
            calcularSumsabutton.Text = "Sumar";
            calcularSumsabutton.UseVisualStyleBackColor = true;
            calcularSumsabutton.MouseClick += calcularSumsabutton_MouseClick;
            // 
            // Resultadolabel
            // 
            Resultadolabel.AutoSize = true;
            Resultadolabel.Location = new Point(256, 499);
            Resultadolabel.Margin = new Padding(4, 0, 4, 0);
            Resultadolabel.Name = "Resultadolabel";
            Resultadolabel.Size = new Size(136, 28);
            Resultadolabel.TabIndex = 6;
            Resultadolabel.Text = "Resultado";
            // 
            // calcularRestarbutton
            // 
            calcularRestarbutton.Font = new Font("Algerian", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            calcularRestarbutton.ForeColor = SystemColors.Desktop;
            calcularRestarbutton.Location = new Point(372, 338);
            calcularRestarbutton.Margin = new Padding(4, 3, 4, 3);
            calcularRestarbutton.Name = "calcularRestarbutton";
            calcularRestarbutton.Size = new Size(242, 77);
            calcularRestarbutton.TabIndex = 7;
            calcularRestarbutton.Text = "Restar";
            calcularRestarbutton.UseVisualStyleBackColor = true;
            calcularRestarbutton.MouseHover += calcularRestarbutton_MouseHover;
            // 
            // calcularMultiplicarbutton
            // 
            calcularMultiplicarbutton.Font = new Font("Algerian", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            calcularMultiplicarbutton.ForeColor = SystemColors.Desktop;
            calcularMultiplicarbutton.Location = new Point(622, 338);
            calcularMultiplicarbutton.Margin = new Padding(4, 3, 4, 3);
            calcularMultiplicarbutton.Name = "calcularMultiplicarbutton";
            calcularMultiplicarbutton.Size = new Size(242, 77);
            calcularMultiplicarbutton.TabIndex = 8;
            calcularMultiplicarbutton.Text = "Multiplicar";
            calcularMultiplicarbutton.UseVisualStyleBackColor = true;
            calcularMultiplicarbutton.MouseLeave += calcularMultiplicarbutton_MouseLeave;
            // 
            // tercerlabel
            // 
            tercerlabel.AutoSize = true;
            tercerlabel.BackColor = SystemColors.ButtonFace;
            tercerlabel.Font = new Font("Showcard Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tercerlabel.ForeColor = SystemColors.HotTrack;
            tercerlabel.Location = new Point(144, 233);
            tercerlabel.Margin = new Padding(4, 0, 4, 0);
            tercerlabel.Name = "tercerlabel";
            tercerlabel.Size = new Size(187, 28);
            tercerlabel.TabIndex = 9;
            tercerlabel.Text = "Tercer Numero";
            // 
            // tercernumerotextBox3
            // 
            tercernumerotextBox3.Location = new Point(389, 226);
            tercernumerotextBox3.Margin = new Padding(4, 3, 4, 3);
            tercernumerotextBox3.Name = "tercernumerotextBox3";
            tercernumerotextBox3.Size = new Size(631, 35);
            tercernumerotextBox3.TabIndex = 10;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(180, 431);
            label1.Name = "label1";
            label1.Size = new Size(151, 28);
            label1.TabIndex = 11;
            label1.Text = "Mouse Click";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(654, 431);
            label2.Name = "label2";
            label2.Size = new Size(153, 28);
            label2.TabIndex = 12;
            label2.Text = "Mouse Leave";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(405, 431);
            label3.Name = "label3";
            label3.Size = new Size(163, 28);
            label3.TabIndex = 13;
            label3.Text = "Mouse Hover";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(14F, 28F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1092, 613);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(tercernumerotextBox3);
            Controls.Add(tercerlabel);
            Controls.Add(calcularMultiplicarbutton);
            Controls.Add(calcularRestarbutton);
            Controls.Add(Resultadolabel);
            Controls.Add(calcularSumsabutton);
            Controls.Add(segundonumerotextBox2);
            Controls.Add(Titlelabel2);
            Controls.Add(primernumerotextBox1);
            Controls.Add(Titlelabel1);
            Font = new Font("Showcard Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Margin = new Padding(4, 3, 4, 3);
            Name = "Form1";
            Text = "Resultado";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label Titlelabel1;
        private TextBox primernumerotextBox1;
        private Label Titlelabel2;
        private TextBox segundonumerotextBox2;
        private Button calcularSumsabutton;
        private Label Resultadolabel;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button calcularRestarbutton;
        private Button calcularMultiplicarbutton;
        private Label tercerlabel;
        private TextBox tercernumerotextBox3;
        private Label label1;
        private Label label2;
        private Label label3;
    }
}
