﻿namespace CafeReservationLibrary.Tarea2
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtCustomerName = new TextBox();
            txtPhoneNumber = new TextBox();
            dateTimePickerReservation = new DateTimePicker();
            label4 = new Label();
            comboBoxTable = new ComboBox();
            btnMakeReservation = new Button();
            btnCancelReservation = new Button();
            label5 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Stencil", 9F);
            label1.Location = new Point(82, 113);
            label1.Name = "label1";
            label1.Size = new Size(205, 21);
            label1.TabIndex = 0;
            label1.Text = "Nombre del cliente:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Stencil", 9F);
            label2.Location = new Point(82, 168);
            label2.Name = "label2";
            label2.Size = new Size(199, 21);
            label2.TabIndex = 1;
            label2.Text = "Numero telefonico:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Stencil", 9F);
            label3.Location = new Point(82, 232);
            label3.Name = "label3";
            label3.Size = new Size(440, 21);
            label3.TabIndex = 2;
            label3.Text = "Para cuantas pesonas seria la reservacion: ";
            // 
            // txtCustomerName
            // 
            txtCustomerName.BackColor = SystemColors.ActiveBorder;
            txtCustomerName.Font = new Font("Stencil", 9F);
            txtCustomerName.Location = new Point(293, 106);
            txtCustomerName.Name = "txtCustomerName";
            txtCustomerName.Size = new Size(242, 29);
            txtCustomerName.TabIndex = 3;
            // 
            // txtPhoneNumber
            // 
            txtPhoneNumber.BackColor = SystemColors.ActiveBorder;
            txtPhoneNumber.Font = new Font("Stencil", 9F);
            txtPhoneNumber.Location = new Point(293, 161);
            txtPhoneNumber.Name = "txtPhoneNumber";
            txtPhoneNumber.Size = new Size(183, 29);
            txtPhoneNumber.TabIndex = 4;
            // 
            // dateTimePickerReservation
            // 
            dateTimePickerReservation.CalendarFont = new Font("Stencil", 9F);
            dateTimePickerReservation.CalendarForeColor = Color.Transparent;
            dateTimePickerReservation.CalendarMonthBackground = SystemColors.ActiveBorder;
            dateTimePickerReservation.Font = new Font("Stencil", 9F);
            dateTimePickerReservation.Location = new Point(331, 281);
            dateTimePickerReservation.Name = "dateTimePickerReservation";
            dateTimePickerReservation.Size = new Size(300, 29);
            dateTimePickerReservation.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Stencil", 9F);
            label4.Location = new Point(82, 290);
            label4.Name = "label4";
            label4.Size = new Size(227, 21);
            label4.TabIndex = 6;
            label4.Text = "Fecha de reservacion:";
            // 
            // comboBoxTable
            // 
            comboBoxTable.BackColor = SystemColors.ActiveBorder;
            comboBoxTable.Font = new Font("Stencil", 9F);
            comboBoxTable.FormattingEnabled = true;
            comboBoxTable.Location = new Point(528, 225);
            comboBoxTable.Name = "comboBoxTable";
            comboBoxTable.Size = new Size(182, 29);
            comboBoxTable.TabIndex = 7;
            // 
            // btnMakeReservation
            // 
            btnMakeReservation.BackColor = SystemColors.ActiveBorder;
            btnMakeReservation.Font = new Font("Stencil", 9F);
            btnMakeReservation.Location = new Point(478, 388);
            btnMakeReservation.Name = "btnMakeReservation";
            btnMakeReservation.Size = new Size(272, 70);
            btnMakeReservation.TabIndex = 8;
            btnMakeReservation.Text = "Hacer Reservacion";
            btnMakeReservation.UseVisualStyleBackColor = false;
            btnMakeReservation.Click += btnMakeReservation_Click;
            // 
            // btnCancelReservation
            // 
            btnCancelReservation.BackColor = SystemColors.ActiveBorder;
            btnCancelReservation.Font = new Font("Stencil", 9F);
            btnCancelReservation.Location = new Point(765, 388);
            btnCancelReservation.Name = "btnCancelReservation";
            btnCancelReservation.Size = new Size(272, 70);
            btnCancelReservation.TabIndex = 9;
            btnCancelReservation.Text = "Cancelar Reservacion";
            btnCancelReservation.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Viner Hand ITC", 20F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label5.Location = new Point(569, 9);
            label5.Name = "label5";
            label5.Size = new Size(363, 65);
            label5.TabIndex = 10;
            label5.Text = "CAFETERIA SOL";
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1370, 539);
            Controls.Add(label5);
            Controls.Add(btnCancelReservation);
            Controls.Add(btnMakeReservation);
            Controls.Add(comboBoxTable);
            Controls.Add(label4);
            Controls.Add(dateTimePickerReservation);
            Controls.Add(txtPhoneNumber);
            Controls.Add(txtCustomerName);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "MainForm";
            Text = "Form1";
            Load += MainForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtCustomerName;
        private TextBox txtPhoneNumber;
        private DateTimePicker dateTimePickerReservation;
        private Label label4;
        private ComboBox comboBoxTable;
        private Button btnMakeReservation;
        private Button btnCancelReservation;
        private Label label5;
    }
}
