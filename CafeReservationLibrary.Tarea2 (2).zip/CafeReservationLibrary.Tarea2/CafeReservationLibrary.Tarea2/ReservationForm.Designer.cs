﻿namespace CafeReservationLibrary.Tarea2
{
    partial class ReservationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReservationForm));
            Reservaciones = new ListBox();
            btnCancel = new Button();
            btnSave = new Button();
            SuspendLayout();
            // 
            // Reservaciones
            // 
            Reservaciones.BackColor = SystemColors.Menu;
            Reservaciones.Font = new Font("Stencil", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Reservaciones.FormattingEnabled = true;
            Reservaciones.ItemHeight = 21;
            Reservaciones.Location = new Point(496, 58);
            Reservaciones.Name = "Reservaciones";
            Reservaciones.Size = new Size(329, 445);
            Reservaciones.TabIndex = 3;
            Reservaciones.SelectedIndexChanged += Reservaciones_SelectedIndexChanged;
            // 
            // btnCancel
            // 
            btnCancel.BackColor = SystemColors.ActiveBorder;
            btnCancel.Font = new Font("Stencil", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCancel.Location = new Point(961, 445);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(181, 58);
            btnCancel.TabIndex = 1;
            btnCancel.Text = "Cancelar Reservacion";
            btnCancel.UseVisualStyleBackColor = false;
            // 
            // btnSave
            // 
            btnSave.BackColor = SystemColors.ActiveBorder;
            btnSave.Font = new Font("Stencil", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSave.Location = new Point(217, 436);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(181, 67);
            btnSave.TabIndex = 0;
            btnSave.Text = "Guardar Reservacion";
            btnSave.UseVisualStyleBackColor = false;
            btnSave.Click += Save_Click;
            // 
            // ReservationForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1262, 605);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(Reservaciones);
            Name = "ReservationForm";
            Text = "ReservationForm";
            ResumeLayout(false);
        }

        #endregion

        private Button btnSave;
        private Button btnCancel;
        private GroupBox groupBox1;
        private ListBox Reservaciones;
    }
}