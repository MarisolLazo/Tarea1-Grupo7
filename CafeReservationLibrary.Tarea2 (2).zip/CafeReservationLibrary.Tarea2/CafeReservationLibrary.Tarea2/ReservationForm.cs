﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CafeReservationLibrary.Tarea2
{
    public partial class ReservationForm : Form
    {
        public ReservationForm()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Logic to save reservation details
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            // Logic to cancel reservation details
            this.Close();
        }

        private void Save_Click(object sender, EventArgs e)
        {

        }

        private void Reservaciones_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }

}
