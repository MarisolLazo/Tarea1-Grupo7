﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CafeReservationLibrary.Tarea2
{
    public class Reservation
    {
        public event EventHandler<ReservationEventArgs> ReservationMade;
        public event EventHandler<ReservationEventArgs> ReservationCancelled;

        public Customer Customer;
        public Table Table;
        public DateTime Date;
        internal object ReservationDate;

        public void MakeReservation()
        {
            OnReservationMade(new ReservationEventArgs(Customer, Table, Date));
        }

        public void CancelReservation()
        {
            OnReservationCancelled(new ReservationEventArgs(Customer, Table, Date));
        }

        protected virtual void OnReservationMade(ReservationEventArgs e)
        {
            ReservationMade?.Invoke(this, e);
        }

        protected virtual void OnReservationCancelled(ReservationEventArgs e)
        {
            ReservationCancelled?.Invoke(this, e);
        }
    }

    public class ReservationEventArgs : EventArgs
    {
        public Customer Customer { get; }
        public Table Table { get; }
        public DateTime Date { get; }

        public ReservationEventArgs(Customer customer, Table table, DateTime date)
        {
            Customer = customer;
            Table = table;
            Date = date;
        }
    }

}


