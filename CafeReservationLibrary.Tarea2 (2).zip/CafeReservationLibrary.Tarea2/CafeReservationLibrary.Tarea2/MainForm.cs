namespace CafeReservationLibrary.Tarea2
{
    using System;
    using System.Windows.Forms;
    using CafeReservationLibrary;

    public partial class MainForm : Form
    {
        private Reservation _currentReservation;

        public MainForm()
        {
            InitializeComponent();
            _currentReservation = new Reservation();
            _currentReservation.ReservationMade += OnReservationMade;
            _currentReservation.ReservationCancelled += OnReservationCancelled;

           
            comboBoxTable.Items.Add("1 - 2 seats");
            comboBoxTable.Items.Add("2 - 4 seats");
            comboBoxTable.Items.Add("3 - 6 seats");
        }

        private void btnMakeReservation_Click(object sender, EventArgs e)
        {
       
            _currentReservation.Customer = new Customer { Name = txtCustomerName.Text, PhoneNumber = txtPhoneNumber.Text };
            _currentReservation.Table = new Table { Number = comboBoxTable.SelectedIndex + 1, Seats = (comboBoxTable.SelectedIndex + 1) * 2 };
            _currentReservation.Date = dateTimePickerReservation.Value;
            _currentReservation.MakeReservation();
        }

        private void btnCancelReservation_Click(object sender, EventArgs e)
        {
            _currentReservation.CancelReservation();
        }

        private void OnReservationMade(object sender, ReservationEventArgs e)
        {
            MessageBox.Show($"Reservacion realizada:\nCliente: {e.Customer.Name}\nMesa: {e.Table.Number}\nFecha: {e.Date}");
        }

        private void OnReservationCancelled(object sender, ReservationEventArgs e)
        {
            MessageBox.Show($"Reservacion Cancelada:\nCliente: {e.Customer.Name}\nMesa: {e.Table.Number}\nFecha: {e.Date}");
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }

}